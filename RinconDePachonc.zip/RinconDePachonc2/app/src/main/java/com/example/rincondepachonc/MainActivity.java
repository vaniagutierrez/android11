package com.example.rincondepachonc;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private TextView tv1, tv2, tv3, tv4, tv5, tv6, tva, tvb, tvc, tvd;
    private EditText et1, et2;
    private Button b1, b2, b3;
    private String [] operaciones = { "Suma", "Resta", "Multiplicación", "División" };
    private Random random;
    private Integer numSuerte;

    RecyclerView rv1;
    String [] nombres = { "Kennen", "Urgot", "Neeko", "Caitlyn", "Yasuo" };
    String [] precios = { "4800 EA / 880 RP", "4800 EA / 880 RP", "6300 EA / 975 RP", "4800 EA / 880 RP", "4800 EA / 880 RP" };
    int [] fotos = { R.drawable.ckennen, R.drawable.curgot, R.drawable.cneeko, R.drawable.ccaitlyn, R.drawable.cyasuo};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        spinner = findViewById(R.id.spinner);
        tv1 = findViewById(R.id.tv1);
        tv2 = findViewById(R.id.tv2);
        tv3 = findViewById(R.id.tv3);
        tv4 = findViewById(R.id.tv4);
        tv5 = findViewById(R.id.tv5);
        tv6 = findViewById(R.id.tv6);
        tva = findViewById(R.id.tva);
        tvb = findViewById(R.id.tvb);
        tvc = findViewById(R.id.tvc);
        tvd = findViewById(R.id.tvd);
        et1 = findViewById(R.id.et1);
        et2 = findViewById(R.id.et2);
        rv1 = findViewById(R.id.rv1);
        numSuerte = null;


        ArrayAdapter<String>adaptadora=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, operaciones);
        spinner.setAdapter(adaptadora);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager( this);
        rv1.setLayoutManager(linearLayoutManager);
        rv1.setAdapter(new AdaptadorPersonaje());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }

    private class AdaptadorPersonaje extends RecyclerView.Adapter <AdaptadorPersonaje.AdaptadorPersonajeHolder> {
        @NonNull
        @Override
        public AdaptadorPersonajeHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdaptadorPersonajeHolder(getLayoutInflater().inflate(R.layout.top_layout, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptadorPersonajeHolder holder, int position) {

            holder.imprimir(position);

        }

        @Override
        public int getItemCount() {
            return nombres.length;
        }

        class AdaptadorPersonajeHolder extends RecyclerView.ViewHolder {

            ImageView iv1;
            TextView tv1, tv2;

            public AdaptadorPersonajeHolder(@NonNull View itemView) {
                super(itemView);
                iv1 = itemView.findViewById(R.id.iv1);
                tv1 = itemView.findViewById(R.id.tvnombre);
                tv2 = itemView.findViewById(R.id.tvprecio);
            }

            @SuppressLint("SetTextI18n")
            public void imprimir(int position) {

                iv1.setImageResource(fotos[position]);
                tv1.setText(nombres[position]);
                tv2.setText("Precio: "+precios[position]);
            }
        }
    }


    @SuppressLint("SetTextI18n")
    public void calcular (View calculo) {

        if (et1.getText().toString().isEmpty() || et2.getText().toString().isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese ambos números", Toast.LENGTH_SHORT).show();
            return;
        }

        double n1 = Double.parseDouble(et1.getText().toString());
        double n2 = Double.parseDouble(et2.getText().toString());
        String operacion = spinner.getSelectedItem().toString();

        if (operacion.equals("Suma")) {
            double suma = n1 + n2;
            tv4.setText("El resultado es: " + suma);
        }
        if (operacion.equals("Resta")) {
            double resta = n1 - n2;
            tv4.setText("El resultado es: " + resta);
        }
        if (operacion.equals("Multiplicación")) {
            double multiplicar = n1 * n2;
            tv4.setText("El resultado es: " + multiplicar);
        }
        if (operacion.equals("División")) {
            if (n2 != 0) {
                double dividir = n1 / n2;
                tv4.setText("El resultado es: " + dividir);
            } else {
                tv4.setText("Error: No es posible dividir por cero.");
            }
        }

    }

    @SuppressLint("SetTextI18n")
    public void azar (View azar) {
        if (numSuerte == null) {
            random = new Random();
            numSuerte = random.nextInt(51);
            tv5.setText("Tu número de la suerte de hoy es: " + numSuerte);
        } else {
            tv5.setText("Tu número de la suerte de hoy es: " + numSuerte);
        }
    }



    public void botonencuesta (View salida) {
        Intent intento = new Intent (this, Encuesta.class);
        startActivity(intento);
    }
}
